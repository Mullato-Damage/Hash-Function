import json  # Import for handling JSON file operations
import tkinter as tk  # Import tkinter for GUI creation
from tkinter import messagebox, simpledialog, filedialog  # Import specific GUI components for dialogs and file browsing
from tkinter.scrolledtext import ScrolledText  # Import ScrolledText for scrollable text box
"""_Program Summary_
    I realized it's pretty easy, once you understand ash functions and how they work, 
    but I didn't want the program to just do the test phases and show it all in the terminal
    so I wanted to use what I've leanred so far to enhance the presentation... and I also wanted the program to look nice, so I went from 70 lines to 200.
"""
class CustomHasher:
    """
    A class to implement a custom hash function that follows OOP principles.
    """

    def __init__(self, salt="5505055"):
        """
        Initialize the hasher with a salt value.
        
        Parameters:
        salt (str): A unique value added to the input for additional randomness to avoid repeat hash outputs, enhancing security. 
        Default salt is "5505055".
        """
        self.salt = salt

    def hash_function(self, plain_text):
        """
        A simple hash function to process input text and return a fixed-length hash.
        
        Parameters:
        plain_text (str): The input string that will be converted to hash.
        
        Returns:
        str: The hashed representation of the input, always 8 characters long, no matter how long the input is.
        """
        # Combine input text with the salt
        # ex. Atlanta + 5505055 = Atlanta5505055
        combined_text = plain_text + self.salt
        # Initialize the hash value
        hash_value = 0
        # Process each character in the combined text (ex. Atlanta5505055)
        for char in combined_text:
            # Update hash using ASCII value and basic mathematical operations
            # ord(char) converts a character into its unicode, like ord('a') = 97
            # we use 31 because it's a prime number, but any other number could be used, but may function differently or cause collisions.
            hash_value = (hash_value * 31 + ord(char)) % (10 ** 8)
        # Return the hash as an 8-character zero-padded string
        return f"{hash_value:08}"


def save_to_json(data, filename="hash_results.json"):
    """
    Save the hash results to a JSON file.
    
    Parameters:
    data (dict): A dictionary containing input texts and their hashed outputs.
    filename (str): Name of the file to save. Default is "hash_results.json".
    """
    try:
        with open(filename, 'w') as file:
            # Write data to JSON file
            json.dump(data, file, indent=4)
        messagebox.showinfo("Save Successful", f"Results saved to {filename}.")
    except Exception as e:
        # Show error message if saving fails
        messagebox.showerror("Save Error", f"Error saving to JSON: {e}")


def load_from_json():
    """
    Load hash results from a selected JSON file and display them in the output box.
    I needed this, because it originally only looked for "hash_results.json" and I started to number each test to see the progress, 
    so I needed to expand the "open save file" option.
    """
    # Open file dialog for selecting a JSON file
    file_path = filedialog.askopenfilename(
        title="Select a JSON File",
        filetypes=[("JSON Files", "*.json"), ("All Files", "*.*")]
    )
    if not file_path:
        return  # Do nothing if the user cancels the dialog

    try:
        with open(file_path, 'r') as file:
            # Load data from the selected JSON file
            loaded_data = json.load(file)
        for key, value in loaded_data.items():
            # Display each input-output pair in the output box
            output_box.insert(tk.END, f"Input: {key}\nHashed Output: {value}\n\n")
        messagebox.showinfo("Load Successful", f"Results loaded from {file_path}.")
    except FileNotFoundError:
        # Handle file not found error
        messagebox.showerror("Load Error", "File not found.")
    except Exception as e:
        # Handle any other errors
        messagebox.showerror("Load Error", f"Error loading from JSON: {e}")


def save_displayed_to_json():
    """
    Save the currently displayed results in the output box to a JSON file.
    """
    displayed_data = output_box.get("1.0", tk.END).strip()  # Get all text from the output box
    try:
        with open("displayed_results.json", 'w') as file:
            # Save the displayed text as-is to a JSON file
            file.write(displayed_data)
        messagebox.showinfo("Save Successful", "Displayed results saved to displayed_results.json.")
    except Exception as e:
        # Handle any saving errors
        messagebox.showerror("Save Error", f"Error saving displayed results: {e}")


def add_user_input():
    """
    Prompt the user for input, hash it, and display the result.
    The porgram didn't feel complete without allowing the user to try the program themself, instead of relying on pre-programmed results.
    """
    user_input = simpledialog.askstring("Input Text", "Enter text to hash:")
    if user_input is not None:
        if len(user_input) > 500:
            # Show an error if the input is too long
            messagebox.showerror("Input Error", "Input text is too long! Please enter less than 500 characters.")
            return
        # Compute the hash of the input
        hashed_output = hasher.hash_function(user_input)
        # Save the input and output in the results dictionary
        results[user_input] = hashed_output
        # Display the input and its hash in the output box
        output_box.insert(tk.END, f"Input: {user_input}\nHashed Output: {hashed_output}\n\n")


def run_tests():
    """
    Run predefined test cases and display the results in the output box.
    """
    test_cases = [
        "HowdyYall", # Test 1: Simple input
        "howdyyall", # Test 2: Case sensitivity
        "",  # Test 3: Empty input
        "@Barktree123",  # Test 4: Input with special characters
        "A" * 100,  # Test 5: Very long input
        "Davey!", # Test 6: repeat inputs with special characters and case sensitivity
        "davey!",
        "Davey!"
    ]
    for test in test_cases:
        # Compute hash for each test case
        hashed_output = hasher.hash_function(test)
        # Save the result in the dictionary and display it
        results[test] = hashed_output
        output_box.insert(tk.END, f"Input: {test}\nHashed Output: {hashed_output}\n\n")


def clear_output():
    """
    Clear all text in the output box.
    """
    output_box.delete("1.0", tk.END)  # Delete everything from the text box


def toggle_dark_mode():
    """
    Toggle between dark and light mode for the GUI.
    I got tired of looking at the box, but didn't feel like taking th etime to customize it beyond optimal button placement, so I figured this was a good option.
    I also just like black
    """
    if dark_mode_var.get():
        # Apply dark mode styles
        root.config(bg="black")
        output_box.config(bg="gray20", fg="white", insertbackground="white")
        dark_mode_button.config(text="Light Mode", bg="gray20", fg="white")
    else:
        # Revert to light mode styles
        root.config(bg="SystemButtonFace")
        output_box.config(bg="white", fg="black", insertbackground="black")
        dark_mode_button.config(text="Dark Mode", bg="SystemButtonFace", fg="black")


# Initialize the hasher instance and results dictionary
hasher = CustomHasher()
results = {}

if __name__ == "__main__":
    # Create the main GUI window
    root = tk.Tk()
    root.title("Custom Hasher")  # Set the window title
    root.geometry("600x500")  # Set the window size

    dark_mode_var = tk.BooleanVar()  # Variable to track dark mode state

    tk.Label(root, text="Custom Hasher", font=("Arial", 16)).pack(pady=10)  # Add a title label

    # Create a scrollable text box for displaying results
    output_box = ScrolledText(root, width=70, height=15, wrap=tk.WORD)
    output_box.pack(pady=10)

    # Run predefined test cases at startup
    run_tests()

    # Create a frame for organizing buttons
    button_frame = tk.Frame(root)
    button_frame.pack(pady=10)

    # Add buttons to the frame
    tk.Button(button_frame, text="Add User Input", command=add_user_input).grid(row=0, column=0, padx=5, pady=5)
    tk.Button(button_frame, text="Save All Results", command=lambda: save_to_json(results)).grid(row=0, column=1, padx=5, pady=5)
    tk.Button(button_frame, text="Save Displayed Results", command=save_displayed_to_json).grid(row=0, column=2, padx=5, pady=5)
    tk.Button(button_frame, text="Load Results", command=load_from_json).grid(row=1, column=0, padx=5, pady=5)
    tk.Button(button_frame, text="Clear Output", command=clear_output).grid(row=1, column=1, padx=5, pady=5)

    # Add a dark mode toggle button
    dark_mode_button = tk.Checkbutton(button_frame, text="Dark Mode", command=toggle_dark_mode, variable=dark_mode_var)
    dark_mode_button.grid(row=1, column=2, padx=5, pady=5)

    # Add an exit button at the bottom of the window
    tk.Button(root, text="Exit", command=root.quit).pack(pady=5)

    # Run the GUI event loop
    root.mainloop()
