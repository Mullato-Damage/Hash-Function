import json  # Import for handling JSON file operations
import tkinter as tk  # Import tkinter for GUI creation
from tkinter import messagebox, simpledialog, filedialog  # Import specific GUI components for dialogs and file browsing
from tkinter.scrolledtext import ScrolledText  # Import ScrolledText for a scrollable text box

"""_Program Summary_
    I realized it's pretty easy, once you understand hash functions and how they work, 
    but I didn't want the program to just do the test phases and show it all in the terminal
    so I wanted to use what I've leanred so far to enhance the presentation... and I also wanted the program to look nice, so I went from 70 lines to 200.
"""

class HashTable:
    """
    A class to implement a hash table with a custom hash function.
    """

    def __init__(self, size=10, salt="5505055"):
        """
        Initialize the hash table with a fixed size and salt value.

        :param size: The number of slots in the hash table.
        :param salt: A unique string added to each key to increase randomness and avoid collisions.
        Default salt is "5505055".
        """
        self.size = size
        self.table = [None] * size  # Create an array of `None` values, each slot representing a hash table index.
        self.salt = salt  # The salt value makes the hash function more unique.

    def hash_function(self, key):
        """
        Generate a raw hash value and table index for the given key.

        :param key: The input string to be hashed.
        :return: A tuple containing the raw hash value and the index in the hash table.
        """
        # Combine the input key with the salt value to create a unique input.
        # ex. Atlanta + 5505055 = Atlanta5505055
        combined_key = key + self.salt

        # Generate the raw hash value by summing the Unicode values of each character in the combined string.
        # ord(char) converts a character into its unicode, like ord('a') = 97
        raw_hash = sum(ord(char) for char in combined_key)

        # Compute the table index by taking the raw hash modulo the size of the hash table.
        index = raw_hash % self.size

        return raw_hash, index  # Return both the raw hash value and the index.

    def insert(self, key, value):
        """
        Insert a key-value pair into the hash table.

        :param key: The input string to hash.
        :param value: The value associated with the key.
        """
        raw_hash, index = self.hash_function(key)  # Generate the hash value and index for the key.
        print(f"Key: {key} -> Raw Hash: {raw_hash}, Index: {index}")  # Debug information for developers.

        # Check if the index in the table is empty.
        if self.table[index] is None:
            self.table[index] = [(key, value)]  # Create a new list at this index to store the key-value pair.
        else:
            # Check if the key already exists; if so, update its value.
            for pair in self.table[index]:
                if pair[0] == key:
                    pair = (key, value)  # Update the value if the key already exists.
                    return
            self.table[index].append((key, value))  # Handle collision by appending to the list.

    def search(self, key):
        """
        Search for a value in the hash table by its key.

        :param key: The key to search for.
        :return: The value associated with the key, or None if the key is not found.
        """
        raw_hash, index = self.hash_function(key)  # Generate the hash value and index for the key.

        # Check if the index contains any data.
        if self.table[index] is not None:
            # Iterate through the list at this index to find the matching key.
            for pair in self.table[index]:
                if pair[0] == key:
                    return pair[1]  # Return the value associated with the key.

        return None  # Return None if the key is not found.

    def display(self, show_debug=False):
        """
        Display the contents of the hash table in the output box.

        :param show_debug: If True, include raw hash values and indices for debugging.
        """
        output_box.delete("1.0", tk.END)  # Clear the output box.

        for i, items in enumerate(self.table):
            if items:
                output_box.insert(tk.END, f"Index {i}:\n")
                for key, value in items:
                    raw_hash, index = self.hash_function(key)
                    truncated_key = (key[:20] + "...") if len(key) > 20 else key
                    truncated_value = (value[:20] + "...") if len(value) > 20 else value
                    output_box.insert(tk.END, f"  Key: {truncated_key}, Value: {truncated_value}\n")
                    if show_debug:
                        output_box.insert(tk.END, f"    (Raw Hash: {raw_hash}, Index: {index})\n")
            else:
                output_box.insert(tk.END, f"Index {i}: Empty\n")


def save_to_json(data, filename="hash_results.json"):
    """
    Save the hash table contents to a JSON file.

    :param data: The hash table data to save.
    :param filename: The name of the JSON file.
    """
    try:
        # Save only the key-value pairs to the file.
        simple_data = {pair[0]: pair[1] for index in hash_table.table if index for pair in index}
        with open(filename, 'w') as file:
            # Write data to JSON file
            json.dump(simple_data, file, indent=4)
        messagebox.showinfo("Save Successful", f"Results saved to {filename}.")
    except Exception as e:
        # Show error message if saving fails
        messagebox.showerror("Save Error", f"Error saving to JSON: {e}")


def load_from_json():
    """
    Load data from a JSON file and insert it into the hash table.
    I needed this, because it originally only looked for "hash_results.json" 
    and I started to number each test to see the progress, 
    so I needed to expand the "open save file" option.

    """
    # Open file dialog for selecting a JSON file
    file_path = filedialog.askopenfilename(
        title="Select a JSON File",
        filetypes=[("JSON Files", "*.json"), ("All Files", "*.*")]
    )
    if not file_path:
        return  # Do nothing if the user cancels the dialog.

    try:
        with open(file_path, 'r') as file:
            # Load data from the selected JSON file
            loaded_data = json.load(file)
        for key, value in loaded_data.items():
            hash_table.insert(key, value)
        messagebox.showinfo("Load Successful", f"Results loaded from {file_path}.")
        hash_table.display()
    except FileNotFoundError:
        # Handle file not found error
        messagebox.showerror("Load Error", "File not found.")
    except Exception as e:
        # Handle any other errors
        messagebox.showerror("Load Error", f"Error loading from JSON: {e}")


def add_user_input():
    """
    Prompt the user for input, hash it, and display the result in the hash table.
    The program didn't feel complete without allowing the user to try the program themself, 
    instead of relying on pre-programmed results.
    """
    user_input = simpledialog.askstring("Input Text", "Enter text to hash:")
    if user_input:
        raw_hash, index = hash_table.hash_function(user_input)
        value = f"Hashed Index: {index} (Raw Hash: {raw_hash})"
        hash_table.insert(user_input, value)
        hash_table.display()


def run_tests():
    """
    Insert predefined test cases into the hash table and display the results.
    """
    test_cases = [
        "HowdyYall", # Test 1: Simple input
        "howdyyall", # Test 2: Case sensitivity
        " ", # Test 3: Empty input
        "@Barktree123", # Test 4: Input with special characters
        "A" * 100, # Test 5: Very long input
        "Davey!", # Test 6: repeat inputs with special characters and case sensitivity
        "davey!", 
        "Davey!", 
    ]
    for test in test_cases:
        # Compute hash for each test case
        raw_hash, index = hash_table.hash_function(test)
        value = f"Hashed Index: {index} (Raw Hash: {raw_hash})"
        hash_table.insert(test, value)
    hash_table.display()


def clear_output():
    """
    Clear all text in the output box.
    """
    output_box.delete("1.0", tk.END)


def toggle_dark_mode():
    """
    Toggle between dark and light mode for the GUI.
    I got tired of looking at the box 
    but didn't feel like taking the time to customize it beyond optimal button placement, so this was a good option.
    """
    if dark_mode_var.get():
        # Apply dark mode styles
        root.config(bg="black")
        output_box.config(bg="gray20", fg="white", insertbackground="white")
        dark_mode_button.config(text="Light Mode", bg="gray20", fg="white")
    else:
        # Revert to light mode styles
        root.config(bg="SystemButtonFace")
        output_box.config(bg="white", fg="black", insertbackground="black")
        dark_mode_button.config(text="Dark Mode", bg="SystemButtonFace", fg="black")


def show_debug():
    """
    Show the hash table with debugging information enabled.
    """
    hash_table.display(show_debug=True)


# GUI Components to create the main GUI window
hash_table = HashTable(size=10)
root = tk.Tk()
root.title("Custom Hasher") # Set the window title
root.geometry("700x550") # Set the window size

dark_mode_var = tk.BooleanVar() # Variable to track dark mode state
tk.Label(root, text="Custom Hasher", font=("Arial", 16)).pack(pady=10) # Add a title label

description_label = tk.Label(
    root,
    text="Inputs are stored in the table based on a calculated number for each input.",
    font=("Arial", 10),
    wraplength=680,
    justify="center",
)
description_label.pack(pady=5)

# Create a scrollable text box for displaying results
output_box = ScrolledText(root, width=80, height=15, wrap=tk.WORD)
output_box.pack(pady=10)

# Create a frame for organizing buttons
button_frame = tk.Frame(root)
button_frame.pack(pady=10)

# Add buttons to the frame
tk.Button(button_frame, text="Add User Input", command=add_user_input).grid(row=0, column=0, padx=5, pady=5)
tk.Button(button_frame, text="Run Tests", command=run_tests).grid(row=0, column=1, padx=5, pady=5)
tk.Button(button_frame, text="Show Debug Info", command=show_debug).grid(row=0, column=2, padx=5, pady=5)
tk.Button(button_frame, text="Save Results", command=lambda: save_to_json(hash_table.table)).grid(row=1, column=0, padx=5, pady=5)
tk.Button(button_frame, text="Load Results", command=load_from_json).grid(row=1, column=1, padx=5, pady=5)
tk.Button(button_frame, text="Clear Output", command=clear_output).grid(row=1, column=2, padx=5, pady=5)

# Add a dark mode toggle button
dark_mode_button = tk.Checkbutton(button_frame, text="Dark Mode", command=toggle_dark_mode, variable=dark_mode_var)
dark_mode_button.grid(row=2, column=1, padx=5, pady=5)

# Add an exit button at the bottom of the window
tk.Button(root, text="Exit", command=root.quit).pack(pady=5)

# Automatically run tests and display the results when the program starts.
run_tests()

# Run the GUI event loop
root.mainloop()
